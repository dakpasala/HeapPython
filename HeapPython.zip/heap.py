class MaxHeap:

    def __init__(self, capacity = 50):
        self.capacity = capacity
        self.heap = [None]
        self.num_items = 0

    def enqueue (self, item):

        if self.is_full():
            return False
        self.num_items += 1
        self.heap.append(item)
        self.perc_up(self.num_items)
        return True

        return True
    def peek(self):
        if self.is_empty():
            return None
        return self.heap[1]

    def dequeue(self):
        if self.is_empty():
            return None
        item = self.heap[1]
        self.heap[1] = self.heap[self.num_items]
        self.heap = self.heap[:self.num_items]
        self.num_items -= 1
        i = self.num_items // 2
        while i > 0:
            self.perc_down(i)
            i -= 1
        return item



    def contents(self):
        return self.heap[1:]

    def get_capacity(self):
        return self.capacity

    def build_heap(self, alist):
        if self.capacity < len(alist):
            self.capacity = len(alist)
        self.heap = [None] + alist
        self.num_items = len(alist)
        i = self.num_items // 2
        while i > 0:
            self.perc_down(i)
            i -= 1

    def is_empty(self):
        return self.num_items == 0

    def is_full(self):
        return self.num_items == self.capacity

    def get_size(self):
        return self.num_items

    def perc_down(self, i ):
       if i == 0:
           raise IndexError
       while i * 2 <= self.num_items:
           c = i * 2
           if i *2 != self.num_items and self.heap[i*2] < self.heap[i * 2 + 1]:
               c += 1
           if self.heap[i] < self.heap[c]:
               self.heap[i], self.heap[c] = self.heap[c], self.heap[i]
           i = c

    def perc_up(self, i):
       while i // 2 > 0:
           if self.heap[i] > self.heap[i // 2]:
               self.heap[i], self.heap[i // 2] = self.heap[i // 2],  self.heap[i]
           i = i // 2

    def heap_sort_ascending(self, alist):
        self.build_heap(alist)
        i = len(alist) - 1
        while i >= 0:
            alist[i] = self.dequeue()
            i -= 1




